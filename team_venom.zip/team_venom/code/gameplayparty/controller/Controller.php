<?php
require_once 'model/Logic.php';
require_once 'model/HtmlModel.php';

class Controller
{
	public function __construct()
	{
		$this->Logic = new Logic();
		$this->HtmlModel = new HtmlModel();
	}

	public function __destruct()
	{ }
	public function handleRequest()
	{
		try {
			$op = isset($_REQUEST['op']) ? $_REQUEST['op'] : NULL;
			switch ($op) {
				case 'getForm':
					$this->collectCreateForm();
					break;
				case 'search':
					$this->collectSearch();
					break;
				case 'create':
					$this->collectCreate();
					break;
				case 'Details':
					$this->collect($_REQUEST['id']);
					break;
				case 'readpage':
					$this->collectPages($_REQUEST['p']);
					break;
				default:
					$this->collectRead();
					break;
			}
		} catch (ValidationException $e) {
			$errors = $e->getErrors();
		}
	}
	public function collectCreateForm()
	{
		//include 'view/createForm.php';
	}
	public function collectCreate()
	{
		// $formData = $_REQUEST;
		// $create = $this->Logic->create($formData);
		// include 'view/create.php';
	}
	public function collect($id)
	{
		// $Details = $this->Logic->read($id);
		// include 'view/Detail.php';
	}
	public function collectSearch()
	{
		// $search = $_REQUEST;
		// $Templates = $this->Logic->search($search);
		// $Search = $this->htmlController->search();
		// $Table = $this->htmlController->createTable($Templates);
		// include 'view/Template.php';
	}

	public function collectRead()
	{
		// $Templates = $this->Logic->read();
		// $Search = $this->htmlController->search();
		// $Table = $this->htmlController->createTable($Templates);
		// include 'view/Template.php';
	}

	public function collectPages()
	{
		// $items_per_page = 4;
		// $position = (($_REQUEST['p'] - 1) * $items_per_page);
		// $result = $this->Logic->readPages($position, $items_per_page);
		// return $result;
		// include 'view/Template.php';
	}
}